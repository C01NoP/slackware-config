#!/usr/bin/env bash

ninja easyeffects-pot
ninja easyeffects-update-po
ninja easyeffects-news-pot
ninja easyeffects-news-update-po